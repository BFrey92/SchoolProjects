﻿using System;


public class Motorcycle
{
    private int speed;
    private string make;
    private int year;
    private int maxSpeed;


    public Motorcycle(int year, string make, int maxSpeed)
    {
        this.year = year;
        this.make = make;
        this.maxSpeed = maxSpeed;
        this.speed = 0;
    }

    public int GetYear()
    {
        return year;
    }

    public void SetYear(int myear)
    {
        year = myear;
    }

    public string GetMake()
    {
        return make;
    }

    public void SetMake(string mMake)
    {
        make = mMake;
    }

    public int GetSpeed()
    {
        return speed;
    }

    public void SetSpeed(int mspeed)
    {
        speed = mspeed;
    }

    public int GetmaxSpeed()
    {
        return maxSpeed;
    }

    public void SetmaxSpeed(int mmaxspeed)
    {
        maxSpeed = mmaxspeed;
    }

    public void stop(Motorcycle Motorcycle)
    {
        Motorcycle.speed = 0;
    }

    public Boolean faster(int speed)
    {
        if (speed <= 0)
        {
            Console.WriteLine("Error, speed cannot be less than 0");
            return false;
        }
        if (speed < this.speed)
        {
            Console.WriteLine("Error, speed cannot exceed " + this.speed);
            return false;
        }
        if (speed + this.speed > this.maxSpeed)
        {
            Console.WriteLine("Error, speed cannot exceed " + this.maxSpeed);
            return false;
        }
        else
        {
            this.speed = speed + this.speed;
            return true;
        }
    }

    public Boolean slower(int speed)
    {
        if (speed >= 0)
        {
            Console.WriteLine("Error, speed cannot be less than 0");
            return false;
        }
        if (this.speed - speed <= 0)
        {
            Console.WriteLine("Error, speed cannot be less than 0");
            return false;
        }
        else
        {
            this.speed = this.speed + speed;
            return true;
        }
    }
}
public class main
{
    public static void Main()
    {
        Motorcycle motorcycle1 = new Motorcycle(1986, "Toyota", 160);
        Motorcycle motorcycle2 = new Motorcycle(1992, "Ford", 180);


        Console.WriteLine(motorcycle1.GetMake());
        Console.WriteLine("Year: " + motorcycle1.GetYear());
        Console.WriteLine("Speed: " + motorcycle1.GetSpeed());
        Console.WriteLine("Max Speed: " + motorcycle1.GetmaxSpeed());
        Console.WriteLine(" ");
        Console.WriteLine(motorcycle2.GetMake());
        Console.WriteLine("Year: " + motorcycle2.GetYear());
        Console.WriteLine("Speed: " + motorcycle2.GetSpeed());
        Console.WriteLine("Max Speed: " + motorcycle2.GetmaxSpeed());
        Console.WriteLine(" ");
        Console.WriteLine("Setting year to 2020:");
        motorcycle1.SetYear(2020);
        Console.WriteLine(motorcycle1.GetMake());
        Console.WriteLine("Year: " + motorcycle1.GetYear());
        Console.WriteLine("Speed: " + motorcycle1.GetSpeed());
        Console.WriteLine("Max Speed: " + motorcycle1.GetmaxSpeed());
        Console.WriteLine(" ");
        Console.WriteLine("Adding 35 to the speed:");
        motorcycle1.faster(35);
        Console.WriteLine(motorcycle1.GetMake());
        Console.WriteLine("Year: " + motorcycle1.GetYear());
        Console.WriteLine("Speed: " + motorcycle1.GetSpeed());
        Console.WriteLine("Max Speed: " + motorcycle1.GetmaxSpeed());
        Console.WriteLine(" ");
        Console.WriteLine("Removing 15 from the speed:");
        motorcycle1.slower(-15);
        Console.WriteLine(motorcycle1.GetMake());
        Console.WriteLine("Year: " + motorcycle1.GetYear());
        Console.WriteLine("Speed: " + motorcycle1.GetSpeed());
        Console.WriteLine("Max Speed: " + motorcycle1.GetmaxSpeed());
        Console.WriteLine(" ");
        Console.WriteLine("Trying to add 180 to speed:");
        motorcycle1.faster(180);
        Console.WriteLine(" ");
        Console.WriteLine("Trying to reduce speed too much");
        motorcycle1.slower(15);
    }
}

