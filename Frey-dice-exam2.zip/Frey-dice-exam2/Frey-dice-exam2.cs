﻿using System;


public class Program
{
	public static void Main()
	{
		string input = null;
		int total = 0;
		int[] dices = new int[4];
		while (input != "quit") 
		{
			Console.Write("Do you want to roll or quit: ");
			input = Console.ReadLine();
			if (input == "roll") 
			{
				dices = rollDice();
				Console.WriteLine("The dice roll is: " + dices[1] + "," + dices[2] + "," + dices[3]);
				total = calculateScore(dices, total);
			}
		}
		if (input == "quit")
		{
			Console.Write("Thanks for playing.");
		}
	}
	public static int[] rollDice()
	{
		int min = 1;
		int max = 6;
		int[] dice = new int[4];
		Random randNum = new Random();
		for (int i = 0; i < dice.Length; i++)
		{
			dice[i] = randNum.Next(min, max);
		}
		return dice;
	}
	public static int calculateScore(int[] dice, int sum)
	{
		int total = 0;
		int full;
		if (dice[1] != dice[2] && dice[2] != dice[3] && dice[1] != dice[3]) //if all integers are different
		{
			total = dice[1] + dice[2] + dice[3];
			Console.WriteLine("No bonus");
		}
		if (dice[1] == dice[2] && dice[2] == dice[3]) //if they are all the same
		{
			total = dice[1] + dice[2] + dice[3] + 50;
			Console.WriteLine("You rolled a triple!");
		}
		else if (dice[1] == dice[2] || dice[2] == dice[3] || dice[1] == dice[3]) //if two of the integers are the same
		{
			total = dice[1] + dice[2] + dice[3] + 25;
			Console.WriteLine("You rolled a double!");
		}
		full = total + sum;
		Console.WriteLine("Your total roll is: " + total);
		Console.WriteLine("Your total score is: " + full);
		return full;
	}
}
