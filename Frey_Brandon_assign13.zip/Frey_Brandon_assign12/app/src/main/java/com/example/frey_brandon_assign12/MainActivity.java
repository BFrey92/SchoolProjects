package com.example.frey_brandon_assign12;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import models.Pokemon;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.ArrayList;
import java.util.Scanner;

public class MainActivity extends AppCompatActivity {

    //You will complete the methods below where you see Javadocs and "COMPLETE THIS METHOD" text.

    private RecyclerView recyclerView;
    private PokemonAdapter pokemonAdapter;
    public ArrayList<Pokemon> pokemonList = new ArrayList<>();
    public static ArrayList<Pokemon> staticList = new ArrayList<>(); //pokemonList is private
    private StringRequest myRequest;
    private final String BASE_API_URL = "https://pokeapi.co/api/v2/pokemon?";
    private int offset = 0;
    private int limit = 20;
    public static boolean ranOnce;

    //Do NOT modify code in onCreate. You may add a line or two near the bottom of the method,
    //if needed.
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        /*if (ranOnce == false) {
            Intent intent = new Intent(this, MapsActivity.class);
            startActivity(intent);
            ranOnce = true;
        }*/
        recyclerView = (RecyclerView) findViewById(R.id.recyclerView);
        pokemonAdapter = new PokemonAdapter(this);
        recyclerView.setAdapter(pokemonAdapter);
        recyclerView.setHasFixedSize(true);
        final GridLayoutManager layoutManager = new GridLayoutManager(this, 3);
        recyclerView.setLayoutManager(layoutManager);

        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);

                //Commented lines were used for initial debugging. I left them here just to show
                //you a few new methods
                if (dy > 0) {
                    //int visibleItemCount = layoutManager.getChildCount();
                    //int totalItemCount = layoutManager.getItemCount();
                    //int pastVisibleItems = layoutManager.findFirstVisibleItemPosition();

                    //If recyclerView CANNOT scroll vertically (1 is vertical), then load more data...
                    if (!recyclerView.canScrollVertically(1)) {
                        //Log.d("visible", String.valueOf(visibleItemCount));
                        //Log.d("past", String.valueOf(pastVisibleItems));
                        //Log.d("total", String.valueOf(totalItemCount));
                        offset += 20;
                        getData(limit, offset);
                    }
                }
            }
        });

        offset = 0;
        getData(limit, offset);
        if (ranOnce == false) {
            Intent intent = new Intent(this, MapsActivity.class);
            startActivity(intent);
            ranOnce = true;
        }
        //You could (but don't have to) add code here.
        //Do not modify the code above because you think it's wrong. It's right. It works.
        //See the Zoom session.
    }

    /**
     * getData uses Android's Volley to load the URL of the Pokemon JSON feed and gather the
     * JSON from the Poke API, such as this: https://pokeapi.co/api/v2/pokemon?limit=10&offset=0
     *
     * After the data is retrieved and isolated into variables, the a Pokemon object  is
     * instantiated for each Pokemon in the feed. For example, the above feed link contains 10
     * pokemon. Thus, 10 Pokemon would be instantiated. As shown in the link above, each Pokemon
     * has two pieces of data, name and url. These are used to populate the Pokemon class (see that
     * class). Each Pokemon also has more data, too, as described in the getProfileData method below.
     *
     * After each Pokemon is instantiated, the Pokemon is added to the pokemonList declared at the
     * top of this class.
     *
     * At some point, this method (or some method) should use the url data gained above (see name and
     * url data points above). You will finish populating the Pokemon objects using that url. See
     * the getProfileData method for more information.
     *
     * @param  limit  Integer. The maximum number of Pokemon to retrieve
     * @param  offset Integer. The numerical location to begin retrieving Pokemon.
     */
    private void getData(int limit, int offset) {
        //COMPLETE THIS METHOD - See the Zoom Class.

        //Build the URL using the BASE_API_URL and the two input parameters, limit and offset.
             myRequest = new StringRequest(Request.Method.GET, BASE_API_URL,
                    response -> {
                        try {
                            JSONObject myJsonObject = new JSONObject(response);
                            int x = myJsonObject.getInt("count");
                            Log.d("Tester", String.valueOf(x));

                            JSONArray testArray = myJsonObject.getJSONArray("results");
                            for (int i = 0; i < testArray.length(); i++) {
                                JSONObject tempObj = testArray.getJSONObject(i);
                                String name = tempObj.getString("name");
                                String pokeUrl = tempObj.getString("url");
                                Log.d("Tester", name);
                                Log.d("Tester", String.valueOf(pokeUrl));
                                Pokemon poke = new Pokemon();
                                poke.setName(name);
                                poke.setUrl(pokeUrl);
                                getProfileData(pokeUrl, poke);
                                pokemonList.add(poke); //was in getProfileData but they appeared out of order
                                pokemonAdapter.addListPokemon(pokemonList);
                            }


                        } catch (JSONException e) {
                            Log.d("API_EXCEPTION", e.getMessage());
                        }
                    },

                    volleyError -> Toast.makeText(MainActivity.this, volleyError.getMessage(), Toast.LENGTH_SHORT).show()
            );


            RequestQueue requestQueue = Volley.newRequestQueue(this);
            requestQueue.add(myRequest);


            requestQueue.addRequestFinishedListener(request -> {
                Log.d("TestDone", "All done now");
            });
        //Use Android Volley to load the Pokemon API URL and parse the JSON Objects/Arrays
        //as needed.

        //Instantiate a Pokemon object with name and url retrieved from JSON.

        //Add the Pokemon object to the pokemonList instance variable.

        //You know you have this right when the code runs and the Recycler view shows the names of
        //the Pokemon characters (no images will appear yet).

        //Debug with the Logcat messages to verify output.

        //You decide when to call getProfileData (see below), which uses the url retrieved  with this
        // method to get baseExperience and id.

        //At some point, you will need to feed the pokemon list to the array adapter with this
        // type of code: pokemonAdapter.addListPokemon(pokemonList);

        //If you later make changes to the Pokemon in the list, you can update the adapter with this:
        //pokemonAdapter.notifyDataSetChanged();
    }

    /**
     * getData uses Android's Volley to load the URL of the Pokemon profile data JSON feed and
     * gather the JSON from the URL. Using this data, you will populate baseExperience and id for
     * the Pokemon character in the URL provided.
     *
     * Whereas the getData method gets a URL where multiple Pokemon are listed, THIS method focuses
     * only on the one Pokemon character in the URL. There is a LOT of data in this URL. It's ok.
     * We only want the id and the baseExperience data.
     *
     * If you want to populate more of the Pokemon data, add additional fields to the Pokemon
     * class.
     *
     * baseExperience will be populated for the Pokemon character. But it doesn't display anywhere
     * currently. So, use Logcat to output the Pokemon's base experience with the tag "experience".
     *
     * You decide where this method will be called. You could call it from getData before or after
     * you add a Pokemon to the array list.
     *
     * @param  url  String. The URL of one Pokemon character's data, such as
     *              https://pokeapi.co/api/v2/pokemon/6/. This url is obtained through the getData
     *              method above, which gets the name and url of each pokemon.
     */
    private void getProfileData(String url, Pokemon poke) { ;
        //COMPLETE THIS METHOD
        //Use Android Volley to load the Pokemon API URL and parse the JSON Objects/Arrays
        //as needed. See method description above.

        //Same song and dance-- except this time, use the url passed into this method to get the
        //base experience and id of the pokemon. Update the pokemon object.

        //If you want to change the function parameters for this function, that's fine.
        myRequest = new StringRequest(Request.Method.GET, url,
                response -> {
                    try {
                        JSONObject myJsonObject = new JSONObject(response);

                       int id = myJsonObject.getInt("id");
                        int exp = myJsonObject.getInt("base_experience");
                        for (int i = 0; i < 1; i++) {
                            Log.d("Tester", "BaseExp: " + exp);
                            poke.setId(id);
                            poke.setBaseExperience(exp);
                            staticList.add(poke);
                            //pokemonList.add(poke); //I had these here originally but they caused the pokemon to appear out of order
                            //pokemonAdapter.addListPokemon(pokemonList);
                            pokemonAdapter.notifyDataSetChanged(); //added because removed addList
                        }

                    } catch (JSONException e) {
                        Log.d("API_EXCEPTION", e.getMessage());
                    }
                },

                volleyError -> Toast.makeText(MainActivity.this, volleyError.getMessage(), Toast.LENGTH_SHORT).show()
        );


        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(myRequest);


        requestQueue.addRequestFinishedListener(request -> {
            Log.d("TestDone", "All done now");
        });

    }

}