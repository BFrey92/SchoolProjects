package com.example.frey_brandon_assign12;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.FragmentActivity;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.location.Location;
import android.os.Bundle;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.target.SimpleTarget;
import com.bumptech.glide.request.transition.Transition;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.Circle;
import com.google.android.gms.maps.model.CircleOptions;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.example.frey_brandon_assign12.databinding.ActivityMapsBinding;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Random;

import models.Pokemon;


public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    private ActivityMapsBinding binding;
    private FusedLocationProviderClient fusedLocationClient;
    private final int LOCATION_PERMISSION_REQUEST_CODE = 1;
    private LocationRequest locationRequest;
    private Location currentLocation;
    private Location previousLocation;
    Button recyclerButton;
    Button deleteButton;
    Marker myMarker;
    private Context context;
    Pokemon pokeNum;

    public MapsActivity(){

    }
    public MapsActivity(Context context) {
        this.context = context;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //Intent intent=new Intent(this, MainActivity.class);
        //startActivity(intent); //If Main doesn't get called, it never runs the code to fill up the list. So start with randomizer open and go back to view map
        binding = ActivityMapsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());


        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this); //HERE
        locationRequest = LocationRequest.create();
        locationRequest.setInterval(10000);
        locationRequest.setFastestInterval(5000);
        locationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        locationRequest.setSmallestDisplacement(5);

        //Ask for permission to access location
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) !=
                PackageManager.PERMISSION_GRANTED ) {

            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                    LOCATION_PERMISSION_REQUEST_CODE);
            return;
        }


        fusedLocationClient.requestLocationUpdates(locationRequest, new LocationCallback() {
                    @Override
                    public void onLocationResult(LocationResult locationResult) {

                        if (locationResult == null) {

                            return;
                        }
                        for (Location location : locationResult.getLocations()) {
                            if (location != null) {
                               // double wayLatitude = location.getLatitude();
                               // double wayLongitude = location.getLongitude();


                                currentLocation = location;

                                //You can subtract 2 distances in an awkard way...
                                //distanceBetween works as shown below.
                                //The results go into the 0 position of an array I call results.
                                float[] results = new float[3];
                                Location.distanceBetween(currentLocation.getLatitude(), currentLocation.getLongitude(),
                                        previousLocation.getLatitude(), previousLocation.getLongitude(), results);

                                Log.d("Difference", String.valueOf(results[0]));
                            }
                            //Log.d("updatedLocation", "null?");
                        }

                    }
                },
                Looper.myLooper()
        );  //ENDS HERE
        recyclerButton = findViewById(R.id.buttonRecycler);
        recyclerButton.setOnClickListener(view -> {
            Intent myIntent=new Intent(this, MainActivity.class);
            //intent.putExtra("context", currentName);
            //intent.putExtra("name", currentName);
            //intent.putExtra("rolls", numRolls);
            startActivity(myIntent);
        });
        deleteButton = findViewById(R.id.buttonDelete);
        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(myMarker != null)
                {
                    myMarker.remove();
                }
            }
        });
    }

    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        mMap.getUiSettings().setZoomControlsEnabled(true);
        if (ActivityCompat.checkSelfPermission(this, //HERE
                android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                    LOCATION_PERMISSION_REQUEST_CODE);
        }
        if (ActivityCompat.checkSelfPermission(this,
                android.Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {

            mMap.setMyLocationEnabled(true);

            //This just gets the initial location of the device. Not that useful because it won't
            //update us when the user changes locations. If you want that, override onLocationResult
            //above.
            fusedLocationClient.getLastLocation().addOnSuccessListener(this, location -> {
                if (location != null) {
                    double wayLatitude = location.getLatitude();
                    double wayLongitude = location.getLongitude();
                    Log.d("currentLocation", String.valueOf(wayLatitude));
                    Log.d("currentLocation", String.valueOf(wayLongitude));
                    LatLng myLocation = new LatLng(wayLatitude, wayLongitude);
                    mMap.addMarker(new MarkerOptions().position(myLocation).title("Current Location"));
                    previousLocation = location;
                }
            });


        }
        else {
            Log.d("currentLocation", "No permission");
            return;
        } //ENDS HERE
        // Add a marker in Sydney and move the camera
        //LatLng sydney = new LatLng(-34, 151);
        //mMap.addMarker(new MarkerOptions().position(sydney).title("Marker in Sydney"));
        //mMap.moveCamera(CameraUpdateFactory.newLatLng(sydney));

        mMap.setOnMapClickListener(new GoogleMap.OnMapClickListener() {
            @Override
            public void onMapClick(@NonNull LatLng latLng) {
                //MarkerOptions m = new MarkerOptions().position(latLng).title("Tester").snippet("Snippy");
                //mMap.addMarker(m).showInfoWindow();
                Pokemon pokeNum = MainActivity.staticList.get(new Random().nextInt(MainActivity.staticList.size()));
                String pokeImg = "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/" + String.valueOf(pokeNum.getId()) + ".png";
                //Glide.with(context)
                       // .asBitmap()
                       // .load(pokeImg);
                        //.into(new SimpleTarget<Bitmap>() {
                            //@Override
                            //public void onResourceReady(@NonNull Bitmap resource, @Nullable Transition<? super Bitmap> transition) {
                                //Bitmap bitmap = Bitmap.createScaledBitmap(resource, 25, 25, true);
                                //MarkerOptions markerOptions = new MarkerOptions().position(latLng)
                                        //.title(pokeNum.getName()) //make pokemon
                                        //.snippet(String.valueOf(latLng))
                                        //.icon(BitmapDescriptorFactory.fromBitmap(resource));
                                //Marker mMarker = googleMap.addMarker(markerOptions);
                           // }

                Location markerLocation = new Location("");
                markerLocation.setLatitude(latLng.latitude);
                markerLocation.setLongitude(latLng.longitude);
                if(currentLocation.distanceTo(markerLocation) < 200)
                {
                    pokeNum.setCaptured(true);
                }
                MarkerOptions markerOptions = new MarkerOptions().position(latLng)
                        .title(pokeNum.getName()) //make pokemon
                        .snippet("Distance: " + String.valueOf(currentLocation.distanceTo(markerLocation)) + " Captured: " + String.valueOf(pokeNum.isCaptured()))
                        //.snippet(String.valueOf(latLng))
                        .icon(BitmapDescriptorFactory.fromBitmap(pokeNum.getBitmap()));
                drawCircle(latLng, googleMap);
                Marker mMarker = googleMap.addMarker(markerOptions);

                //BitmapDescriptor icon = BitmapDescriptorFactory.fromBitmap(convertToBitmap(d,100,100));
                //MarkerOptions markerOptions = new MarkerOptions().position(latLng)
                        //.title(pokeNum.getName()) //make pokemon
                       // .snippet(String.valueOf(latLng))
                       // .icon(BitmapDescriptorFactory.fromBitmap(resource));
                //Marker mMarker = googleMap.addMarker(markerOptions);
                mMap.setOnMarkerClickListener(new GoogleMap.OnMarkerClickListener() {
                    @Override
                    public boolean onMarkerClick(Marker m) {
                        myMarker = m;
                        return false;}
                });
            }

            });

    }
    private void drawCircle(LatLng point, GoogleMap googleMap){

        // Instantiating CircleOptions to draw a circle around the marker
        CircleOptions circleOptions = new CircleOptions();

        // Specifying the center of the circle
        circleOptions.center(point);

        // Radius of the circle
        circleOptions.radius(200);

        // Border color of the circle
        circleOptions.strokeColor(Color.BLACK);

        // Fill color of the circle
        circleOptions.fillColor(0x30ff0000);

        // Border width of the circle
        circleOptions.strokeWidth(2);

        // Adding the circle to the GoogleMap
        googleMap.addCircle(circleOptions);

    }


}