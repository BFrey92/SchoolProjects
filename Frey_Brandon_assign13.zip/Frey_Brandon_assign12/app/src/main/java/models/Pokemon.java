package models;

import android.graphics.Bitmap;

public class Pokemon {
    //You do NOT need to change anything here. You CAN ADD fields here if you want to load more
    //Pokemon data. Do not remove data from here. It's all needed. :) See the Zoom session.
    private int id;
    private int baseExperience;
    private Bitmap bitmap;

    private String name;
    private String url;
    private boolean captured;


    public void setBaseExperience(int exp) {
        this.baseExperience = exp;
    }

    public int getBaseExperience() {
        return this.baseExperience;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setBitmap(Bitmap bitmap){this.bitmap = bitmap;}
    public Bitmap getBitmap(){return bitmap;}

    public void setCaptured(boolean captured){this.captured = captured;}
    public boolean isCaptured(){return captured;}


}