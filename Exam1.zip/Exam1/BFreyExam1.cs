﻿using System;
using static System.Console;

namespace Exam1
{
    class Program
    {
        static void Main()
        {
            double minutesOver = 0; //minutes over
            string userName; //user's name
            string planNumber; //plan's number
            double planNumberInt;
            string minutesUsed; //minutes used
            double minutesUsedint; //minutes used as integer
            double planCharge = 0; //base plan price/charge
            double overPrice = 0;  //price per overage minute
            string totalMins = ("0"); //total minutes for plan before overages
            double overCharge = 0; //total charge for overages
            double totalBill = 0; //total bill price
            double costSaving1; //amount saved for using plan 1
            costSaving1 = 0;
            double costSaving2; //amount saved for using plan 2
            costSaving2 = 0;
            double costSaving3; //amount saved for using plan 3
            costSaving3 = 0;
            WriteLine("Enter the customer's name: ");
            userName = ReadLine();
            while (userName.Length < 2)
            {
                WriteLine("Error: name must be no less than 2 characters."); //if username less than 2, ends here
                WriteLine("Enter the customer's name: ");
                userName = ReadLine();
            }
            WriteLine("Enter a plan: ");
            planNumber = ReadLine();
            planNumberInt = Convert.ToDouble(planNumber);
            while (planNumberInt < 1 || planNumberInt > 3)
            {
                WriteLine("Error: please enter a correct plan.");
                WriteLine("Enter a plan: ");
                planNumber = ReadLine();
                planNumberInt = Convert.ToDouble(planNumber);
            }
            WriteLine("Enter the number of minutes used: ");
            minutesUsed = ReadLine();
            minutesUsedint = Convert.ToDouble(minutesUsed);
            while (minutesUsedint < 0)
            {
                WriteLine("Error: minutes used must be zero or greater."); //if minutes used less than 0, ends here
                WriteLine("Enter the number of minutes used: ");
                minutesUsed = ReadLine();
                minutesUsedint = Convert.ToDouble(minutesUsed);
            }               
            if (planNumber == "1")
            {
                totalMins = ("400");
                overPrice = 0.35;
                planCharge = 29.99;
                if (minutesUsedint > 400)
                {
                    minutesOver = (minutesUsedint - 400);
                    overCharge = (minutesOver * overPrice);
                }
                else
                {
                    overCharge = 0;
                }
                totalBill = (planCharge + overCharge);
                if (minutesUsedint > 800)
                {
                    costSaving2 = totalBill - (49.99 + (minutesUsedint - 800) * 0.30);
                }
                else
                {
                    costSaving2 = totalBill - 49.99;
                }
                costSaving3 = totalBill - 59.99;
            }
            if (planNumber == "2")
            {
                planCharge = 49.99;
                totalMins = ("800");
                overPrice = 0.30;
                if (minutesUsedint > 800)
                {
                    minutesOver = (minutesUsedint - 800);
                    overCharge = (minutesOver * overPrice);
                }
                else
                {
                    overCharge = 0;
                }
                totalBill = (planCharge + overCharge);
                if (minutesUsedint > 400)
                {
                    costSaving1 = totalBill - (29.99 + (minutesUsedint - 400) * 0.35);
                }
                else
                {
                    costSaving1 = totalBill - 29.99;
                }
                costSaving3 = totalBill - 59.99;
            }
            if (planNumber == "3")
            {
                totalMins = ("Unlimited");
                minutesOver = 0;
                overPrice = 0;
                overCharge = 0;
                planCharge = 59.99;
                totalBill = 59.99;
                if (minutesUsedint > 400)
                {
                    costSaving1 = totalBill - (29.99 + (minutesUsedint - 400) * 0.35);
                }
                else
                {
                    costSaving1 = totalBill - 29.99;
                }
                if (minutesUsedint > 800)
                {
                    costSaving2 = totalBill - (49.99 + (minutesUsedint - 800) * 0.30);
                }
                else
                {
                    costSaving2 = totalBill - 49.99;
                }
            }
            WriteLine("Bill Name: " + userName);
            WriteLine("Plan: " + planNumber);
            WriteLine("Plan Base Charge: $" + planCharge);
            WriteLine("Plan Base Minutes: " + totalMins);
            WriteLine("Overage Minutes: " + minutesOver);
            WriteLine("Price Per Minute Overage: $" + overPrice);
            WriteLine("Overage Charge: $" + Math.Round(overCharge, 2));
            WriteLine("Total Bill: $" + Math.Round(totalBill, 2));
            if (costSaving1 > 0 || costSaving2 > 0 || costSaving3 > 0)
            {
                WriteLine("Cost Savings: ");
                if (costSaving1 > 0)
                {
                    WriteLine("If you switched to Plan 1, you would have saved $" + Math.Round(costSaving1, 2));
                }
                if (costSaving2 > 0)
                {
                    WriteLine("If you switched to Plan 2, you would have saved $" + Math.Round(costSaving2, 2));
                }
                if (costSaving3 > 0)
                {
                    WriteLine("If you switched to Plan 3, you would have saved $" + Math.Round(costSaving3, 2));
                }
            }
        }
    }
}
