package com.example.frey_brandon_assign_6_1;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;


public class ScoresAdapter extends RecyclerView.Adapter<ScoresAdapter.ListItemHolder>{
    private List<Scores> mScoresList;
    private MainActivity mMainActivity;


    public ScoresAdapter(List<Scores> scoresList) {

        //mMainActivity = mainActivity;
        mScoresList = scoresList;
    }


    @NonNull
    @Override
    public ScoresAdapter.ListItemHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.listitem,parent,false);

        return new ListItemHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull ScoresAdapter.ListItemHolder holder, int position) {
        Scores Scores = mScoresList.get(position);
        holder.mName.setText(Scores.getName());
        holder.mScore.setText(Scores.getTotalScore());
        holder.mDoubles.setText(Scores.getDoubles());
        holder.mTriples.setText(Scores.getTriples());

    }

    @Override
    public int getItemCount() {
        return mScoresList.size();
    }

    public class ListItemHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        TextView mName;
        TextView mScore;
        TextView mDoubles;
        TextView mTriples;


        public ListItemHolder(View view) {
            super(view);

            mName =
                    view.findViewById(R.id.textViewName);

            mScore = view.findViewById(R.id.textViewScore);
            mDoubles = view.findViewById(R.id.textViewDoubles);
            mTriples = view.findViewById(R.id.textViewTriples);

            /*view.setClickable(true);
            view.setOnClickListener(this);*/

        }

        @Override
        public void onClick(View view) {
            //mMainActivity.showNote(getAdapterPosition());
        }
    }
}
