package com.example.frey_brandon_assign_6_1;

import android.os.Parcel;
import android.os.Parcelable;

public class Dice implements Parcelable{
    int dice1;
    int dice2;
    int dice3;
    int totalRoll;
    static boolean doubleChoices;
    static boolean tripleChoices;

    public static void doubleChoice(boolean doubleChoice) {
        doubleChoices = doubleChoice;

    }

    public static void tripleChoice(boolean tripleChoice) {
        tripleChoices = tripleChoice;
    }


    public Dice (int dice1, int dice2, int dice3, int totalRoll) {
        this.dice1 = dice1;
        this.dice2 = dice2;
        this.dice3 = dice3;
        this.totalRoll = totalRoll;
    }

    public void rollDice (int dice1, int dice2, int dice3, int totalRoll) {
        dice1 = (int)(Math.random()*6) + 1; //rolls between 0-5 and + 1 makes it 1-6
        dice2 = (int)(Math.random()*6) + 1;
        dice3 = (int)(Math.random()*6) + 1;
        //textViewResults.setText("Result of Dice Roll \n" + dice1); //add dice roll here
        //textViewDiceLeft.setText(String.valueOf(dice2));
        //textViewDiceRight.setText(String.valueOf(dice3));
        totalRoll += (dice1 + dice2 + dice3); //accumulated rolls, total adds dice to itself and keeps the new value
        //textViewTotalScore.setText("Total Score \n" + totalRoll); //add total of all rolls here
    }

    protected Dice(Parcel in) {
        dice1 = in.readInt();
        dice2 = in.readInt();
        dice3 = in.readInt();
        totalRoll = in.readInt();
    }

    public static final Creator<Dice> CREATOR = new Creator<Dice>() {
        @Override
        public Dice createFromParcel(Parcel in) {
            return new Dice(in);
        }

        @Override
        public Dice[] newArray(int size) {
            return new Dice[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(dice1);
        parcel.writeInt(dice2);
        parcel.writeInt(dice3);
        parcel.writeInt(totalRoll);
    }
}
