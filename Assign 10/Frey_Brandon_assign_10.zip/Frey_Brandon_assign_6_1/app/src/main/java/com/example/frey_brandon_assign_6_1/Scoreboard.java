package com.example.frey_brandon_assign_6_1;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class Scoreboard extends AppCompatActivity {

    //views
    public TextView textTotalRolls;
    public TextView textThanks;
    public RecyclerView editTextScoreName;
    private ScoresAdapter mAdapter;
    List<Scores> scoresList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.scoreboard);
        Button returnButton = findViewById(R.id.buttonReturn);
        TextView textTotalRolls = findViewById(R.id.textTotalRolls);
        TextView textThanks = findViewById(R.id.textThanks);
        RecyclerView editTextScoreName = findViewById(R.id.recyclerView);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
        editTextScoreName.setItemAnimator(new DefaultItemAnimator());
        editTextScoreName.addItemDecoration(new DividerItemDecoration(this, LinearLayoutManager.VERTICAL));
        editTextScoreName.setLayoutManager(mLayoutManager);
        Bundle bundle = getIntent().getExtras();
        mAdapter = new ScoresAdapter(scoresList);
        editTextScoreName.setAdapter(mAdapter);
        String username = bundle.getString("name");
        int rolls = bundle.getInt("rolls");

        textTotalRolls.setText(String.format("%s Total Dice Rolls: ", rolls));
        textThanks.setText(String.format("Thanks for playing, %s", username));

        SharedPreferences Stats = getSharedPreferences("DiceGame", MODE_PRIVATE);
        Map<String, ?> allEntries = Stats.getAll();

        StringBuilder Scores = new StringBuilder();

        for(Map.Entry<String, ?> entry : allEntries.entrySet()){
            Scores.append(String.format("%s : %s\n",entry.getKey(), entry.getValue().toString()));
            String[] separated = entry.getValue().toString().split(":");
            Scores score = new Scores();
            score.setName("Name: " + entry.getKey());
            score.setTotalScore("Total Score: " + separated[0]);
            score.setDoubles("Doubles: " + separated[1]);
            score.setTriples("Triples: " + separated[2]);
            scoresList.add(score);
            mAdapter.notifyDataSetChanged();
            Log.d("map values", entry.getKey() + ": " + entry.getValue().toString());
        }
        //editTextScoreName.setText(Scores);
        returnButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }

}
