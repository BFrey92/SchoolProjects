package com.example.frey_brandon_assign_6_1;

import androidx.fragment.app.DialogFragment;
import android.app.AlertDialog;
import android.app.Dialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;

public class DialogOptions extends DialogFragment {
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        LayoutInflater inflater = getActivity().getLayoutInflater();
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        View dialogView = inflater.inflate(R.layout.double_triple, null);
        builder.setView(dialogView).setMessage("Settings");

        CheckBox checkBoxDouble = dialogView.findViewById(R.id.checkBoxDouble);
        CheckBox checkBoxTriple = dialogView.findViewById(R.id.checkBoxTriple);
        Button btnSave = dialogView.findViewById(R.id.btnSave);
        Button btnCancel = dialogView.findViewById(R.id.btnCancel);

        checkBoxDouble.setChecked(Dice.doubleChoices);
        checkBoxTriple.setChecked(Dice.tripleChoices);

        btnCancel.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dismiss();
            }
        });

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Dice.doubleChoice(checkBoxDouble.isChecked());
                Dice.tripleChoice(checkBoxTriple.isChecked());
                dismiss();
            }
        });




        return builder.create();
    }
}
