package com.example.frey_brandon_assign_6_1;

public class Scores {
    private String name;
    private String doubles;
    private String triples;
    private String totalScore;

    public String getName(){ return name; }
    public void setName(String name){ this.name = name;}

    public String getDoubles(){return doubles;}
    public void setDoubles(String doubles) {this.doubles = doubles;}

    public String getTriples(){return triples;}
    public void setTriples(String triples) {this.triples = triples;}

    public String getTotalScore(){return totalScore;}
    public void setTotalScore(String totalScore) {this.totalScore = totalScore;}
}
