package com.example.frey_brandon_assign_6_1;

import static java.util.Objects.isNull;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.view.GestureDetectorCompat;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.text.Editable;
import android.util.Log;
import android.view.GestureDetector;
import android.view.MenuInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.view.animation.RotateAnimation;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.BreakIterator;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class MainActivity extends AppCompatActivity implements GestureDetector.OnGestureListener {

    int totalRoll = 0; //var for accumulated value
    int numRolls = 0;
    SharedPreferences Stats;
    //Editable currentName;
    String currentName;
    String previousName;
    int numDoubles = 0;
    int numTriples = 0;
    RotateAnimation rotate;
    private GestureDetectorCompat gDetector;
    private static int MinX = 100;
    private static int MinY = 100;
    private static int MaxX = 1000;
    private static int MaxY = 1000;
    Button rollButton;
    TextView textViewResults;
    TextView textViewTotalScore;
    TextView textViewDiceLeft;
    TextView textViewDiceRight;
    EditText editTextName;
    Button scoreboardButton;
    EditText editTextScoreName;
    TextView textTotalRolls;
    TextView textThanks;
    TextView DoubleTriple;
    ImageView imageOne;
    ImageView imageTwo;
    ImageView imageThree;
    MediaPlayer mp;
    SharedPreferences.Editor editor;
    //Scores score = new Scores();
    //List<Scores> scoresList = new ArrayList<>();
    //private RecyclerView recyclerView;
    //private ScoresAdapter mAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_constraint); //layout goes here!

        rollButton = findViewById(R.id.buttonRoll);
        textViewResults = findViewById(R.id.textViewResults);
        textViewTotalScore = findViewById(R.id.textViewTotalScore);
        textViewDiceLeft = findViewById(R.id.textViewDiceLeft);
        textViewDiceRight = findViewById(R.id.textViewDiceRight);
        editTextName = findViewById(R.id.editTextName);
        scoreboardButton = findViewById(R.id.buttonScoreboard);
        editTextScoreName = findViewById(R.id.editTextScoreName);
        textTotalRolls = findViewById(R.id.textTotalRolls);
        textThanks = findViewById(R.id.textThanks);
        DoubleTriple = findViewById(R.id.textViewDoubleTriple);
        imageOne = findViewById(R.id.imageView);
        imageTwo = findViewById(R.id.imageView2);
        imageThree = findViewById(R.id.imageView3);
        rotate = new RotateAnimation(0, 360);
        rotate.setDuration(500);
        mp = MediaPlayer.create(this, R.raw.dice);
        this.gDetector = new GestureDetectorCompat(this, this);

        //recyclerView = findViewById(R.id.recyclerView);

        //recyclerView.setLayoutManager(new LinearLayoutManager(this));
        Stats = getSharedPreferences("DiceGame", Context.MODE_PRIVATE); //shared pref
        editor = Stats.edit();
        editor.clear();
        editor.commit();
        //mAdapter = new ScoresAdapter(scoresList);
        //RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());

        /*recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.addItemDecoration(new DividerItemDecoration(this, LinearLayoutManager.VERTICAL));
        recyclerView.setAdapter(mAdapter);*/

        //can use Integer.toString() to display only an integer in setText
        //String.valueOf() works as well
        //all below needs to go into dice class

        /*rollButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int diceRoll; //var for dice roll value
                int diceRoll2;
                int diceRoll3;
                imageOne.startAnimation(rotate); //INVOKING ANIMATION FOR ALL THREE DICE IMAGES
                imageTwo.startAnimation(rotate);
                imageThree.startAnimation(rotate);
                mp.start();
                mp.setVolume(100,100);
                DoubleTriple.setText("");
                currentName = String.valueOf(editTextName.getText());
                //score.setName(currentName);
                diceRoll = (int)(Math.random()*6) + 1; //rolls between 0-5 and + 1 makes it 1-6
                diceRoll2 = (int)(Math.random()*6) + 1;
                diceRoll3 = (int)(Math.random()*6) + 1;
                textViewResults.setText("Result of Dice Roll \n" + diceRoll); //add dice roll here
                textViewDiceLeft.setText(String.valueOf(diceRoll2)); //may need to change diceRoll's to dice1, dice2, dice3
                textViewDiceRight.setText(String.valueOf(diceRoll3));
                switch(diceRoll){
                    case 1:
                        imageTwo.setImageResource(R.drawable.die_1);
                        break;
                    case 2:
                        imageTwo.setImageResource(R.drawable.die_2);
                        break;
                    case 3:
                        imageTwo.setImageResource(R.drawable.die_3);
                        break;
                    case 4:
                        imageTwo.setImageResource(R.drawable.die_4);
                        break;
                    case 5:
                        imageTwo.setImageResource(R.drawable.die_5);
                        break;
                    case 6:
                        imageTwo.setImageResource(R.drawable.die_6);
                        break;
                }
                switch(diceRoll2){
                    case 1:
                        imageThree.setImageResource(R.drawable.die_1);
                        break;
                    case 2:
                        imageThree.setImageResource(R.drawable.die_2);
                        break;
                    case 3:
                        imageThree.setImageResource(R.drawable.die_3);
                        break;
                    case 4:
                        imageThree.setImageResource(R.drawable.die_4);
                        break;
                    case 5:
                        imageThree.setImageResource(R.drawable.die_5);
                        break;
                    case 6:
                        imageThree.setImageResource(R.drawable.die_6);
                        break;
                }
                switch(diceRoll3){
                    case 1:
                        imageOne.setImageResource(R.drawable.die_1);
                        break;
                    case 2:
                        imageOne.setImageResource(R.drawable.die_2);
                        break;
                    case 3:
                        imageOne.setImageResource(R.drawable.die_3);
                        break;
                    case 4:
                        imageOne.setImageResource(R.drawable.die_4);
                        break;
                    case 5:
                        imageOne.setImageResource(R.drawable.die_5);
                        break;
                    case 6:
                        imageOne.setImageResource(R.drawable.die_6);
                        break;
                }
                numRolls = numRolls + 1;
                if (currentName.equals(previousName)) {

                    totalRoll += (diceRoll + diceRoll2 + diceRoll3);
                }//accumulated rolls, total adds dice to itself and keeps the new value
                else {
                    totalRoll = (diceRoll + diceRoll2 + diceRoll3);

                }
                    //editor.putString("name", String.valueOf(currentName));
                    //editor.putString(currentName, currentName);
                    //Map<String,?> allEntries = Stats.getAll();
                    //for (Map.Entry<String, ?> entry : allEntries.entrySet()) {
                        //Log.d("map values", entry.getKey() + ": " + entry.getValue().toString());
                    //}
                    previousName = String.valueOf(editTextName.getText());
                if (Dice.doubleChoices == true){
                    if (diceRoll == diceRoll2 && diceRoll != diceRoll3) {
                        totalRoll = totalRoll+50;
                        DoubleTriple.setText("Double!");
                        if (currentName.equals(previousName)) {
                            numDoubles = numDoubles + 1;
                        }
                        else{
                            numDoubles = 1;
                        }
                    }
                    if (diceRoll == diceRoll3 && diceRoll != diceRoll2) {
                        totalRoll = totalRoll+50;
                        DoubleTriple.setText("Double!");
                        if (currentName.equals(previousName)) {
                            numDoubles = numDoubles + 1;
                        }
                        else{
                            numDoubles = 1;
                        }
                    }
                    if (diceRoll3 == diceRoll2 && diceRoll3 != diceRoll) {
                        totalRoll = totalRoll+50;
                        DoubleTriple.setText("Double!");
                        if (currentName.equals(previousName)) {
                            numDoubles = numDoubles + 1;
                        }
                        else{
                            numDoubles = 1;
                        }
                    }
                }
                if (Dice.tripleChoices == true){
                    if (diceRoll == diceRoll2 && diceRoll == diceRoll3){
                        totalRoll = totalRoll+100;
                        DoubleTriple.setText("Triple!");
                        if (currentName.equals(previousName)) {
                            numTriples = numTriples + 1;
                        }
                        else{
                            numTriples = 1;
                        }
                    }
                }
                //score.setTotalScore(totalRoll);
                //score.setDoubles(numDoubles);
                //score.setTriples(numTriples);
                //scoresList.add(score);
                //mAdapter.notifyDataSetChanged();
                editor.putString(currentName, String.valueOf(totalRoll) + ":" +String.valueOf(numDoubles) + ":" + String.valueOf(numTriples));
                //editor.putInt(String.valueOf(numRolls), numRolls);
                editor.commit();
                textViewTotalScore.setText("Total Score \n" + totalRoll); //add total of all rolls here
                //onSaveInstanceState and onResumeInstanceState
            }
        });*/
        //under 3 original
        //scoreboardButton.setOnClickListener(new View.OnClickListener() {
            //@Override
            //public void onClick(View view) {
        //new under
        scoreboardButton.setOnClickListener(view -> {
            Intent intent=new Intent(getBaseContext(), Scoreboard.class);
            //intent.putExtra("context", currentName);
            intent.putExtra("name", currentName);
            intent.putExtra("rolls", numRolls);
            startActivity(intent);
        });
                ////setContentView(R.layout.scoreboard);
                ////Intent intent=new Intent(MainActivity.this, Scoreboard.class);
                //intent.putExtra("context", currentName);
                ////intent.putExtra("name", editTextName.getText());
                ////intent.putExtra("rolls", numRolls);
                //sendBroadcast(intent);
               // startActivity(intent);
                //under is in scoreboard.java as well
//                String name = Stats.getString("name", "");
//                int total = Stats.getInt("score", 0);
//                int numRolls = Stats.getInt("numRolls", 0);
//                //not in scoreboard.java under here
//                textThanks.setText("Thank you for playing, " + name);
//                Map<String, ?> allEntries = Stats.getAll();
//                for (Map.Entry<String, ?> entry : allEntries.entrySet()) {
//                    Log.d("map values", entry.getKey() + ": " + entry.getValue().toString());
//                    editTextScoreName.setText(entry.getValue().toString());
//                }

            }
       //// });
    ////}

    @Override
    public boolean onCreateOptionsMenu (Menu menu) {
        getMenuInflater().inflate(R.menu.options_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        //Toast.makeText(this, "Selected Item: " +item.getTitle(), Toast.LENGTH_SHORT).show();
        switch (item.getItemId()) {
            case R.id.settings:
                DialogOptions dialog = new DialogOptions();
                dialog.show(getSupportFragmentManager(), "settingsDialog");
                return true;
            case R.id.about:
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public boolean onDown(MotionEvent motionEvent) {
        return false;
    }

    @Override
    public void onShowPress(MotionEvent motionEvent) {

    }

    @Override
    public boolean onSingleTapUp(MotionEvent motionEvent) {
        return false;
    }

    @Override
    public boolean onScroll(MotionEvent motionEvent, MotionEvent motionEvent1, float v, float v1) {
        return false;
    }

    @Override
    public void onLongPress(MotionEvent motionEvent) {

    }

    @Override
    public boolean onFling(MotionEvent motionEvent, MotionEvent motionEvent1, float v, float v1) {
        float deltaX = motionEvent.getX() - motionEvent1.getX();
        float deltaY = motionEvent.getY() - motionEvent1.getY();
        float deltaXAbs = Math.abs(deltaX);
        float deltaYAbs = Math.abs(deltaY);
        if((deltaXAbs >= MinX) && (deltaXAbs <= MaxX) || (deltaYAbs >= MinY && deltaYAbs <= MaxY))
        {
            int diceRoll; //var for dice roll value
            int diceRoll2;
            int diceRoll3;
            imageOne.startAnimation(rotate); //INVOKING ANIMATION FOR ALL THREE DICE IMAGES
            imageTwo.startAnimation(rotate);
            imageThree.startAnimation(rotate);
            mp.start();
            mp.setVolume(100,100);
            DoubleTriple.setText("");
            currentName = String.valueOf(editTextName.getText());
            //score.setName(currentName);
            diceRoll = (int)(Math.random()*6) + 1; //rolls between 0-5 and + 1 makes it 1-6
            diceRoll2 = (int)(Math.random()*6) + 1;
            diceRoll3 = (int)(Math.random()*6) + 1;
            textViewResults.setText("Result of Dice Roll \n" + diceRoll); //add dice roll here
            textViewDiceLeft.setText(String.valueOf(diceRoll2)); //may need to change diceRoll's to dice1, dice2, dice3
            textViewDiceRight.setText(String.valueOf(diceRoll3));
            switch(diceRoll){
                case 1:
                    imageTwo.setImageResource(R.drawable.die_1);
                    break;
                case 2:
                    imageTwo.setImageResource(R.drawable.die_2);
                    break;
                case 3:
                    imageTwo.setImageResource(R.drawable.die_3);
                    break;
                case 4:
                    imageTwo.setImageResource(R.drawable.die_4);
                    break;
                case 5:
                    imageTwo.setImageResource(R.drawable.die_5);
                    break;
                case 6:
                    imageTwo.setImageResource(R.drawable.die_6);
                    break;
            }
            switch(diceRoll2){
                case 1:
                    imageThree.setImageResource(R.drawable.die_1);
                    break;
                case 2:
                    imageThree.setImageResource(R.drawable.die_2);
                    break;
                case 3:
                    imageThree.setImageResource(R.drawable.die_3);
                    break;
                case 4:
                    imageThree.setImageResource(R.drawable.die_4);
                    break;
                case 5:
                    imageThree.setImageResource(R.drawable.die_5);
                    break;
                case 6:
                    imageThree.setImageResource(R.drawable.die_6);
                    break;
            }
            switch(diceRoll3){
                case 1:
                    imageOne.setImageResource(R.drawable.die_1);
                    break;
                case 2:
                    imageOne.setImageResource(R.drawable.die_2);
                    break;
                case 3:
                    imageOne.setImageResource(R.drawable.die_3);
                    break;
                case 4:
                    imageOne.setImageResource(R.drawable.die_4);
                    break;
                case 5:
                    imageOne.setImageResource(R.drawable.die_5);
                    break;
                case 6:
                    imageOne.setImageResource(R.drawable.die_6);
                    break;
            }
            numRolls = numRolls + 1;
            if (currentName.equals(previousName)) {

                totalRoll += (diceRoll + diceRoll2 + diceRoll3);
            }//accumulated rolls, total adds dice to itself and keeps the new value
            else {
                totalRoll = (diceRoll + diceRoll2 + diceRoll3);

            }
            //editor.putString("name", String.valueOf(currentName));
            //editor.putString(currentName, currentName);
            //Map<String,?> allEntries = Stats.getAll();
            //for (Map.Entry<String, ?> entry : allEntries.entrySet()) {
            //Log.d("map values", entry.getKey() + ": " + entry.getValue().toString());
            //}
            previousName = String.valueOf(editTextName.getText());
            if (Dice.doubleChoices == true){
                if (diceRoll == diceRoll2 && diceRoll != diceRoll3) {
                    totalRoll = totalRoll+50;
                    DoubleTriple.setText("Double!");
                    if (currentName.equals(previousName)) {
                        numDoubles = numDoubles + 1;
                    }
                    else{
                        numDoubles = 1;
                    }
                }
                if (diceRoll == diceRoll3 && diceRoll != diceRoll2) {
                    totalRoll = totalRoll+50;
                    DoubleTriple.setText("Double!");
                    if (currentName.equals(previousName)) {
                        numDoubles = numDoubles + 1;
                    }
                    else{
                        numDoubles = 1;
                    }
                }
                if (diceRoll3 == diceRoll2 && diceRoll3 != diceRoll) {
                    totalRoll = totalRoll+50;
                    DoubleTriple.setText("Double!");
                    if (currentName.equals(previousName)) {
                        numDoubles = numDoubles + 1;
                    }
                    else{
                        numDoubles = 1;
                    }
                }
            }
            if (Dice.tripleChoices == true){
                if (diceRoll == diceRoll2 && diceRoll == diceRoll3){
                    totalRoll = totalRoll+100;
                    DoubleTriple.setText("Triple!");
                    if (currentName.equals(previousName)) {
                        numTriples = numTriples + 1;
                    }
                    else{
                        numTriples = 1;
                    }
                }
            }
            //score.setTotalScore(totalRoll);
            //score.setDoubles(numDoubles);
            //score.setTriples(numTriples);
            //scoresList.add(score);
            //mAdapter.notifyDataSetChanged();
            editor.putString(currentName, String.valueOf(totalRoll) + ":" +String.valueOf(numDoubles) + ":" + String.valueOf(numTriples));
            //editor.putInt(String.valueOf(numRolls), numRolls);
            editor.commit();
            textViewTotalScore.setText("Total Score \n" + totalRoll); //add total of all rolls here
            //onSaveInstanceState and onResumeInstanceState

        }
        return true;
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        this.gDetector.onTouchEvent(event);
        return super.onTouchEvent(event);
    }


}