"use strict";
var studentScore = [];

var studentName = [];

const displayScores = (scores, scoresString) => {
	var avgScore = 0;
	var string = "";
	for (let i = 0; i < studentScore.length; i++) {
		avgScore = avgScore + parseFloat(studentScore[i]);
	}
	avgScore = avgScore/(studentScore.length);
	$("#average_score").text(avgScore.toFixed(2));
	for (let i = 0; i < scoresString.length; i++) {
		string += (scoresString[i].toString() + "\n");
		$("#scores").val(string);
	}
};

$(document).ready( () => {
    $("#add_button").click( () => {
        studentName.push((document.getElementById("last_name").value + ", " + document.getElementById("first_name").value + " - " + parseFloat(document.getElementById("score").value)));
        studentScore.unshift(parseFloat(document.getElementById("score").value));
		displayScores(studentScore, studentName);
        // get the add form ready for next entry
        $("#first_name").val( "" );
        $("#last_name").val( "" );
        $("#score").val( "" );
        $("#first_name").focus();
    }); // end click()
    
    $("#clear_button").click( () => {
		studentName.length = 0;
		studentScore.length = 0;
        // remove the score data from the web page
        $("#average_score").text( "" );
        $("#scores").val( "" );

        $("#first_name").focus();
    }); // end click()
       
    $("#sort_button").click( () => {
		studentName.sort();
		$("#average_score").text( "" );
        $("#scores").val( "" );
		displayScores(studentScore, studentName);
    }); // end click()
    
    $("#first_name").focus();
}); // end ready()
